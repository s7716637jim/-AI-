
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { Product, InventoryStats } from './types';
import { MOCK_PRODUCTS, Icons } from './constants';
import { getSmartStockSuggestions } from './services/aiService';
import { fetchProductsFromGoogleSheet } from './services/googleSheetsService';

const STORAGE_KEY = 'stock_master_last_sheet_id';

type FilterStatus = 'all' | 'issue' | 'online_zero' | 'physical_zero' | 'low_stock' | 'discontinued';
type SortKey = 'default' | 'physical_desc' | 'physical_asc' | 'online_desc' | 'online_asc';

const App: React.FC = () => {
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [filterType, setFilterType] = useState<FilterStatus>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortKey, setSortKey] = useState<SortKey>('default');
  const [isUpdating, setIsUpdating] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [replenishNotice, setReplenishNotice] = useState<string[] | null>(null);
  const [showCloudModal, setShowCloudModal] = useState(false);
  const [showSortMenu, setShowSortMenu] = useState(false);
  const [sheetId, setSheetId] = useState('');
  const [isCloudConnected, setIsCloudConnected] = useState(false);

  const safeNum = (val: any): number => {
    const num = Number(val);
    return isNaN(num) ? 0 : num;
  };

  const performSync = useCallback(async (targetId: string) => {
    if (!targetId.trim()) return;
    setIsUpdating(true);
    setStatusMessage("正在同步雲端資料...");
    try {
      const cloudData = await fetchProductsFromGoogleSheet(targetId);
      setProducts(cloudData);
      setIsCloudConnected(true);
      setShowCloudModal(false);
      localStorage.setItem(STORAGE_KEY, targetId);
      setStatusMessage(`同步成功！共載入 ${cloudData.length} 筆商品`);
    } catch (err: any) {
      setStatusMessage(err.message || "連線失敗，請檢查權限");
      setIsCloudConnected(false);
    } finally {
      setIsUpdating(false);
      setTimeout(() => setStatusMessage(null), 4000);
    }
  }, []);

  useEffect(() => {
    const savedId = localStorage.getItem(STORAGE_KEY);
    if (savedId) {
      setSheetId(savedId);
      performSync(savedId);
    }
  }, [performSync]);

  const stats: InventoryStats = useMemo(() => {
    return {
      totalItems: products.length,
      outOfStock: products.filter(p => {
        const os = safeNum(p.onlineStock);
        const ps = safeNum(p.physicalStock);
        return (os === 0 && ps > 0) || (os > ps);
      }).length,
      lowStock: products.filter(p => {
        const os = safeNum(p.onlineStock);
        return os > 0 && os < 5;
      }).length,
      totalValue: products.reduce((acc, p) => acc + (safeNum(p.price) * safeNum(p.onlineStock)), 0)
    };
  }, [products]);

  const filteredProducts = useMemo(() => {
    // 1. 篩選
    let result = products.filter(p => {
      const os = safeNum(p.onlineStock);
      const ps = safeNum(p.physicalStock);
      
      const matchesSearch = 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        p.sku.toLowerCase().includes(searchQuery.toLowerCase());
      
      if (!matchesSearch) return false;

      switch (filterType) {
        case 'issue':
          return (os === 0 && ps > 0) || (os > ps) || (os < 5 && ps > os + 5);
        case 'online_zero':
          return os === 0;
        case 'physical_zero':
          return ps === 0;
        case 'low_stock':
          return os > 0 && os < 5;
        case 'discontinued':
          return p.isDiscontinued === true;
        default:
          return true;
      }
    });

    // 2. 排序
    switch (sortKey) {
      case 'physical_desc':
        result.sort((a, b) => b.physicalStock - a.physicalStock);
        break;
      case 'physical_asc':
        result.sort((a, b) => a.physicalStock - b.physicalStock);
        break;
      case 'online_desc':
        result.sort((a, b) => b.onlineStock - a.onlineStock);
        break;
      case 'online_asc':
        result.sort((a, b) => a.onlineStock - b.onlineStock);
        break;
      default:
        // 如果是預設則不變動
        break;
    }

    return [...result];
  }, [products, filterType, searchQuery, sortKey]);

  const handleUpdateOnlineStock = (id: string, delta: number) => {
    setProducts(prev => prev.map(p => {
      if (p.id === id) {
        const current = safeNum(p.onlineStock);
        return { ...p, onlineStock: Math.max(0, current + delta) };
      }
      return p;
    }));
  };

  const handleOneClickQueryIssue = () => {
    setFilterType('issue');
    setSearchQuery('');
    setStatusMessage("已顯示庫存待優化項目");
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const handleOneClickAutoAdjust = async () => {
    setIsUpdating(true);
    setStatusMessage("AI 正在優化庫存...");
    
    const problematic = products.filter(p => {
      const os = safeNum(p.onlineStock);
      const ps = safeNum(p.physicalStock);
      if (p.isDiscontinued) return false;
      const isZero = os === 0 && ps > 0;
      const isOver = os > ps;
      const isLowButPlenty = os < 5 && ps > os + 5;
      return isZero || isOver || isLowButPlenty;
    });

    if (problematic.length === 0) {
      setStatusMessage("目前庫存水位健康，無需調整");
      setIsUpdating(false);
      setTimeout(() => setStatusMessage(null), 3000);
      return;
    }

    try {
      const resultsMap = await getSmartStockSuggestions(problematic);
      const replenishedNames: string[] = [];

      setProducts(prev => prev.map(p => {
        const result = resultsMap[p.id];
        if (result !== undefined) {
          if (result.isReplenishment) {
            replenishedNames.push(p.name);
          }
          return { ...p, onlineStock: result.suggestion };
        }
        return p;
      }));

      if (replenishedNames.length > 0) {
        setReplenishNotice(replenishedNames);
        setTimeout(() => setReplenishNotice(null), 6000);
      }
      
      setStatusMessage(`AI 已優化 ${Object.keys(resultsMap).length} 項商品庫存！`);
    } catch (error) {
      setStatusMessage("AI 服務暫時無法連線");
    } finally {
      setIsUpdating(false);
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  const handleSyncCloud = () => {
    performSync(sheetId);
  };

  const handleDisconnect = () => {
    localStorage.removeItem(STORAGE_KEY);
    setSheetId('');
    setIsCloudConnected(false);
    setProducts(MOCK_PRODUCTS);
    setStatusMessage("已還原預設資料");
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const FilterPill: React.FC<{ type: FilterStatus; label: string }> = ({ type, label }) => (
    <button 
      onClick={() => setFilterType(type)}
      className={`px-4 py-2 rounded-full text-[11px] font-bold whitespace-nowrap transition-all border ${
        filterType === type 
        ? 'bg-slate-900 text-white border-slate-900 shadow-lg' 
        : 'bg-white text-slate-500 border-slate-100'
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="min-h-screen max-w-md mx-auto bg-slate-50 flex flex-col relative pb-32 shadow-2xl overflow-hidden text-slate-900">
      <header className="sticky top-0 bg-white/80 backdrop-blur-md z-40 border-b border-slate-100">
        <div className="px-6 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">庫存大師 <span className="text-indigo-600">AI</span></h1>
            <p className="text-[10px] text-slate-500 font-semibold tracking-tighter uppercase">
              {isCloudConnected ? 'Cloud Sync Active' : 'Demo Mode'}
            </p>
          </div>
          <button 
            onClick={() => setShowCloudModal(true)}
            className={`px-3 py-1.5 rounded-2xl text-[10px] font-bold uppercase tracking-widest flex items-center space-x-1.5 transition-all active:scale-95 ${isCloudConnected ? 'bg-indigo-50 text-indigo-700' : 'bg-emerald-50 text-emerald-700'}`}
          >
            <Icons.Cloud />
            <span>{isCloudConnected ? '設定' : '讀取雲端'}</span>
          </button>
        </div>
        
        {/* 搜尋與排序 */}
        <div className="px-6 pb-4 flex items-center space-x-2">
          <div className="relative flex-1 group">
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors">
              <Icons.Search />
            </div>
            <input 
              type="text"
              placeholder="搜尋名稱或 SKU..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-100 border-none rounded-2xl py-3 pl-11 pr-4 text-xs focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all placeholder:text-slate-400"
            />
          </div>
          <div className="relative">
            <button 
              onClick={() => setShowSortMenu(!showSortMenu)}
              className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all ${sortKey !== 'default' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'bg-slate-100 text-slate-500'}`}
            >
              <Icons.Sort />
            </button>
            
            {showSortMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-[24px] shadow-2xl border border-slate-100 py-3 z-50 animate-in fade-in zoom-in duration-200">
                <div className="px-5 py-2 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-50 mb-1">庫存排序</div>
                {[
                  { k: 'default', l: '預設排序' },
                  { k: 'physical_desc', l: '實體：多 → 少' },
                  { k: 'physical_asc', l: '實體：少 → 多' },
                  { k: 'online_desc', l: '線上：多 → 少' },
                  { k: 'online_asc', l: '線上：少 → 多' },
                ].map(item => (
                  <button 
                    key={item.k}
                    onClick={() => { setSortKey(item.k as SortKey); setShowSortMenu(false); }}
                    className={`w-full text-left px-5 py-3 text-xs font-bold transition-colors ${sortKey === item.k ? 'text-indigo-600 bg-indigo-50' : 'text-slate-600 hover:bg-slate-50'}`}
                  >
                    {item.l}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* 橫向過濾標籤 */}
        <div className="px-6 pb-4 overflow-x-auto no-scrollbar flex space-x-2">
          <FilterPill type="all" label="全部" />
          <FilterPill type="issue" label="⚡️ 異常" />
          <FilterPill type="online_zero" label="線上 0" />
          <FilterPill type="physical_zero" label="實體 0" />
          <FilterPill type="low_stock" label="低水位" />
          <FilterPill type="discontinued" label="📦 絕版" />
        </div>
      </header>

      {/* 補貨通知彈窗 */}
      {replenishNotice && (
        <div className="fixed top-40 left-6 right-6 z-50 bg-indigo-600 text-white p-4 rounded-3xl shadow-2xl animate-in slide-in-from-top duration-500 flex items-start space-x-3 border border-white/20">
          <div className="bg-white/20 p-2 rounded-xl mt-0.5">
            <Icons.Magic />
          </div>
          <div className="flex-1">
            <h4 className="text-[13px] font-black uppercase tracking-wider mb-1">AI 補貨通知</h4>
            <p className="text-[11px] leading-relaxed opacity-90">
              檢測到 <span className="font-bold underline">{replenishNotice.length}</span> 項商品已從實體撥入線上：<br/>
              <span className="italic">{replenishNotice.slice(0, 2).join(', ')}{replenishNotice.length > 2 ? '...' : ''}</span>
            </p>
          </div>
          <button onClick={() => setReplenishNotice(null)} className="p-1 opacity-50 hover:opacity-100 transition-opacity">
            <Icons.Close />
          </button>
        </div>
      )}

      {/* 統計數值區塊 */}
      <section className="px-6 py-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white p-5 rounded-[32px] shadow-sm border border-slate-100">
            <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest block mb-1">顯示結果</span>
            <span className="text-2xl font-black text-slate-800 tabular-nums">
              {filteredProducts.length}<span className="text-slate-300 mx-1">/</span>{stats.totalItems}
            </span>
          </div>
          <div 
            onClick={handleOneClickQueryIssue}
            className={`p-5 rounded-[32px] shadow-sm border transition-all cursor-pointer active:scale-95 ${stats.outOfStock > 0 ? 'bg-orange-50 border-orange-100 animate-pulse' : 'bg-white border-slate-100'}`}
          >
            <span className={`text-[10px] font-black uppercase tracking-widest block mb-1 ${stats.outOfStock > 0 ? 'text-orange-500' : 'text-slate-400'}`}>庫存異常</span>
            <span className={`text-2xl font-black tabular-nums ${stats.outOfStock > 0 ? 'text-orange-600' : 'text-slate-800'}`}>{safeNum(stats.outOfStock)}</span>
          </div>
        </div>
      </section>

      <main className="px-6 space-y-4 flex-1 overflow-y-auto pb-4">
        {filteredProducts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-slate-400">
            <div className="bg-slate-100 p-6 rounded-full mb-4">
              <Icons.Search />
            </div>
            <p className="text-xs font-bold uppercase tracking-widest">無符合條件的商品</p>
          </div>
        ) : (
          filteredProducts.map((product) => {
            const os = safeNum(product.onlineStock);
            const ps = safeNum(product.physicalStock);
            const isOverSold = os > ps;
            const isOutOfStockOnline = os === 0 && ps > 0;
            const isLowButPlenty = os < 5 && ps > os + 5;
            
            return (
              <div 
                key={product.id} 
                className={`bg-white p-5 rounded-[32px] border transition-all ${product.isDiscontinued ? 'opacity-70 grayscale-[0.3]' : ''} ${isOverSold || isOutOfStockOnline || isLowButPlenty ? 'border-orange-200 shadow-lg shadow-orange-50' : 'border-slate-100 shadow-sm'}`}
              >
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1 mr-2">
                    <div className="flex items-center flex-wrap gap-1.5 mb-1">
                      <h3 className="font-bold text-slate-800 text-sm leading-tight">{product.name}</h3>
                      {product.isDiscontinued && (
                        <span className="bg-slate-100 text-slate-500 text-[8px] font-black px-1.5 py-0.5 rounded-full uppercase">絕版</span>
                      )}
                      {isOverSold && (
                        <span className="bg-orange-100 text-orange-600 text-[8px] font-black px-1.5 py-0.5 rounded-full uppercase">超賣</span>
                      )}
                      {isOutOfStockOnline && (
                        <span className="bg-rose-100 text-rose-600 text-[8px] font-black px-1.5 py-0.5 rounded-full uppercase">補貨</span>
                      )}
                      {isLowButPlenty && (
                        <span className="bg-indigo-100 text-indigo-600 text-[8px] font-black px-1.5 py-0.5 rounded-full uppercase">充裕</span>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-400 font-mono uppercase tracking-widest">{product.sku}</p>
                  </div>
                  {!product.isDiscontinued && (
                    <div className="flex flex-col space-y-1">
                      <button 
                        onClick={() => handleUpdateOnlineStock(product.id, 1)}
                        className="w-7 h-7 rounded-lg bg-slate-50 text-indigo-600 flex items-center justify-center active:bg-indigo-600 active:text-white transition-all border border-slate-100"
                      >
                        <Icons.Plus />
                      </button>
                      <button 
                        onClick={() => handleUpdateOnlineStock(product.id, -1)}
                        className="w-7 h-7 rounded-lg bg-slate-50 text-slate-400 flex items-center justify-center active:bg-rose-500 active:text-white transition-all border border-slate-100"
                      >
                        <Icons.Minus />
                      </button>
                    </div>
                  )}
                </div>
                
                <div className="grid grid-cols-2 gap-3 mt-4">
                  <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-100">
                    <span className="text-[8px] text-slate-400 block font-bold uppercase mb-0.5">實體庫存</span>
                    <span className="text-sm font-black text-slate-700">{ps}</span>
                  </div>
                  <div className={`p-2.5 rounded-2xl border transition-colors ${isOverSold ? 'bg-orange-50 border-orange-200' : isOutOfStockOnline ? 'bg-rose-50 border-rose-100' : 'bg-indigo-50 border-indigo-100'}`}>
                    <span className={`text-[8px] block font-bold uppercase mb-0.5 ${isOverSold ? 'text-orange-500' : 'text-indigo-400'}`}>線上庫存</span>
                    <span className={`text-sm font-black ${isOverSold ? 'text-orange-600' : isOutOfStockOnline ? 'text-rose-600' : 'text-indigo-700'}`}>
                      {os}
                    </span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </main>

      <footer className="fixed bottom-8 left-1/2 -translate-x-1/2 w-[calc(100%-48px)] max-w-[340px] z-30">
        <div className="bg-slate-900/95 backdrop-blur-xl p-3 rounded-[32px] shadow-2xl flex items-center space-x-3 border border-white/10">
          <button 
            onClick={handleOneClickQueryIssue}
            className={`flex-1 flex flex-col items-center justify-center p-2 rounded-2xl transition-all ${filterType === 'issue' ? 'text-orange-400 bg-white/10' : 'text-slate-400'}`}
          >
            <Icons.Alert />
            <span className="text-[9px] mt-1 font-black uppercase">待補</span>
          </button>
          
          <button 
            disabled={isUpdating}
            onClick={handleOneClickAutoAdjust}
            className={`flex-[2.5] py-4 rounded-2xl font-black text-xs flex items-center justify-center space-x-2 transition-all active:scale-95 shadow-lg ${
              isUpdating 
              ? 'bg-slate-800 text-slate-500' 
              : 'bg-indigo-500 text-white shadow-indigo-500/40'
            }`}
          >
            {isUpdating ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            ) : (
              <>
                <Icons.Magic />
                <span>一鍵智能調庫存</span>
              </>
            )}
          </button>

          <button 
            onClick={handleSyncCloud}
            className="flex-1 flex flex-col items-center justify-center p-2 rounded-2xl text-slate-400 hover:text-white hover:bg-white/10 transition-all"
          >
            <Icons.Sync />
            <span className="text-[9px] mt-1 font-black uppercase">同步</span>
          </button>
        </div>
      </footer>

      {showCloudModal && (
        <div className="fixed inset-0 z-50 flex items-end justify-center px-6 pb-12">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" onClick={() => setShowCloudModal(false)}></div>
          <div className="relative bg-white w-full max-w-sm rounded-[40px] p-8 shadow-2xl animate-in slide-in-from-bottom duration-500">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-black text-slate-800 tracking-tight">雲端同步設定</h2>
              <button onClick={() => setShowCloudModal(false)} className="p-2 text-slate-400"><Icons.Close /></button>
            </div>
            <div className="space-y-6">
              <div className="bg-indigo-50 p-4 rounded-2xl border border-indigo-100/50">
                <p className="text-[11px] text-indigo-900 leading-relaxed font-medium">
                  將根據試算表標題自動偵測「名稱、線上、實際、料號」欄位。
                </p>
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 ml-2 uppercase block mb-2">Google Sheet ID / URL</label>
                <input 
                  type="text" 
                  placeholder="在此貼上..."
                  value={sheetId}
                  onChange={(e) => setSheetId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-4 text-sm focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all"
                />
              </div>
              <div className="flex space-x-2">
                <button 
                  onClick={handleSyncCloud}
                  className="flex-[2] bg-slate-900 text-white py-4.5 rounded-[22px] font-black text-sm active:scale-95 transition-all"
                >
                  立即同步
                </button>
                {isCloudConnected && (
                  <button onClick={handleDisconnect} className="flex-1 bg-rose-50 text-rose-600 py-4.5 rounded-[22px] font-black text-[10px] uppercase">
                    中斷
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {statusMessage && !replenishNotice && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 bg-slate-900 text-white px-6 py-3 rounded-full text-[11px] font-black shadow-2xl z-50 animate-in fade-in zoom-in duration-300 flex items-center space-x-2">
          <div className="w-2 h-2 bg-indigo-400 rounded-full animate-ping"></div>
          <span>{statusMessage}</span>
        </div>
      )}
    </div>
  );
};

export default App;
