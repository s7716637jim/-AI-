
import { GoogleGenAI, Type } from "@google/genai";
import { Product } from "../types";

export interface StockAdjustment {
  id: string;
  suggestion: number;
  reason: string;
}

export const getSmartStockSuggestions = async (problematicProducts: Product[]): Promise<Record<string, { suggestion: number, isReplenishment: boolean }>> => {
  if (problematicProducts.length === 0) return {};

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
  
  const productsPayload = problematicProducts.map(p => ({
    id: p.id,
    name: p.name,
    physical: p.physicalStock,
    online: p.onlineStock,
    scenario: p.onlineStock === 0 ? "線上缺貨" : (p.onlineStock > p.physicalStock ? "線上超賣" : "低水位補貨")
  }));

  const prompt = `
    你是一個專業的電商庫存調度員。請針對以下三種場景提供「線上庫存調整建議」：
    
    1. 【線上缺貨】(online=0): 請從實體庫存撥一部分到線上（例如撥 50%）。
    2. 【線上超賣】(online>physical): 必須將線上數量調低，絕對不能超過實體庫存。
    3. 【低水位補貨】(online<5): 如果實體庫存充裕，建議適度增加線上數量。
    
    限制：建議值 (suggestion) 絕對不能超過實體庫存 (physical)，且必須是整數。
    
    商品清單: ${JSON.stringify(productsPayload)}
    
    請回傳 JSON 陣列，包含 id 和 suggestion (數字)。
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              suggestion: { type: Type.NUMBER }
            },
            required: ["id", "suggestion"]
          }
        }
      }
    });

    const results = JSON.parse(response.text);
    const suggestionMap: Record<string, { suggestion: number, isReplenishment: boolean }> = {};
    
    results.forEach((item: { id: string, suggestion: number }) => {
      const originalProduct = problematicProducts.find(p => p.id === item.id);
      if (originalProduct) {
        const finalSuggestion = Math.max(0, Math.min(Math.round(item.suggestion), originalProduct.physicalStock));
        suggestionMap[item.id] = {
          suggestion: finalSuggestion,
          isReplenishment: originalProduct.onlineStock === 0 && finalSuggestion > 0
        };
      }
    });
    return suggestionMap;
  } catch (error) {
    console.error("Gemini AI error:", error);
    const fallback: Record<string, { suggestion: number, isReplenishment: boolean }> = {};
    problematicProducts.forEach(p => {
      fallback[p.id] = { 
        suggestion: p.physicalStock, 
        isReplenishment: p.onlineStock === 0 && p.physicalStock > 0 
      };
    });
    return fallback;
  }
};
