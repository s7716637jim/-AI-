
import { Product } from "../types";

/**
 * 強大的 CSV 行解析器，支援處理引號內的逗號
 */
const parseCSVLine = (line: string): string[] => {
  const result = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      result.push(cur);
      cur = '';
    } else {
      cur += char;
    }
  }
  result.push(cur);
  return result;
};

/**
 * 數字清洗：確保輸出為純數字
 */
const cleanNumber = (val: any): number => {
  if (val === null || val === undefined) return 0;
  const str = String(val).trim();
  const cleaned = str.replace(/[^\d.-]/g, '');
  const num = parseFloat(cleaned);
  return isNaN(num) ? 0 : num;
};

export const fetchProductsFromGoogleSheet = async (sheetId: string): Promise<Product[]> => {
  // 1. 處理 URL 或 ID
  const cleanId = sheetId.includes('/d/') ? sheetId.match(/\/d\/([^\/]+)/)?.[1] || sheetId : sheetId;
  const url = `https://docs.google.com/spreadsheets/d/${cleanId}/export?format=csv&timestamp=${Date.now()}`;
  
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error("無法讀取試算表，請確認權限已開啟為「知道連結的人即可檢視」。");
    
    let csvText = await response.text();
    
    // 2. 移除 UTF-8 BOM (常見於 Excel/Google 匯出的 CSV)
    if (csvText.charCodeAt(0) === 0xFEFF) {
      csvText = csvText.substring(1);
    }

    const lines = csvText.split(/\r?\n/).filter(line => line.trim() !== '');
    if (lines.length < 2) throw new Error("試算表內容不足（至少需要標題列與一行資料）。");

    // 3. 智慧解析標題列 (Header)
    const headers = parseCSVLine(lines[0]).map(h => h.trim().toLowerCase());
    
    // 定義關鍵字搜尋規則
    const findIndex = (keywords: string[], defaultIdx: number) => {
      const idx = headers.findIndex(h => keywords.some(k => h.includes(k)));
      return idx === -1 ? defaultIdx : idx;
    };

    const idxName = findIndex(['名稱', '品名', 'name', 'title', '商品'], 0);
    const idxPhysical = findIndex(['實際', '現場', '現貨', '庫存', 'physical', 'stock', 'qty'], 1);
    const idxOnline = findIndex(['線上', '網店', '蝦皮', '官網', 'online', 'web'], 2);
    const idxSku = findIndex(['料號', '編號', 'sku', 'id', 'code'], 3);
    const idxDisc = findIndex(['絕版', '狀態', 'discontinued', 'status', '下架'], 4);

    console.log("偵測到欄位索引:", { 
      名稱: idxName, 實際: idxPhysical, 線上: idxOnline, 料號: idxSku 
    });

    // 4. 解析資料列
    const products: Product[] = lines.slice(1).map((line, index) => {
      const row = parseCSVLine(line).map(cell => cell.trim());
      
      const name = row[idxName] || `商品 ${index + 1}`;
      const physicalStock = cleanNumber(row[idxPhysical]);
      const onlineStock = cleanNumber(row[idxOnline]);
      const sku = row[idxSku] || `SKU-${index}`;
      
      const discStr = (row[idxDisc] || "").toLowerCase();
      const isDiscontinued = ["是", "y", "1", "true", "絕版", "yes"].includes(discStr);

      // 如果這是用戶提到的 BABY-1004，印出詳細資訊以利偵錯
      if (name.includes('BABY-1004') || sku.includes('BABY-1004')) {
        console.log("偵錯 BABY-1004:", { row, name, physicalStock, onlineStock, sku });
      }
      
      return {
        id: `cloud-${index}-${sku}`,
        name,
        category: "雲端同步",
        physicalStock: Math.max(0, physicalStock),
        onlineStock: Math.max(0, onlineStock),
        price: 0,
        sku,
        isDiscontinued
      };
    });

    return products;
  } catch (error) {
    console.error("同步發生錯誤:", error);
    throw error;
  }
};
