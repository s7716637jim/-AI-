
export interface Product {
  id: string;
  name: string;
  category: string;
  physicalStock: number; // 實際庫存
  onlineStock: number;   // 線上庫存
  price: number;
  sku: string;
  isDiscontinued?: boolean;
}

export interface InventoryStats {
  totalItems: number;
  outOfStock: number; // 指線上缺貨
  lowStock: number;
  totalValue: number;
}
