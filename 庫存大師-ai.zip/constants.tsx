
import React from 'react';
import { Product } from './types';

export const MOCK_PRODUCTS: Product[] = [
  { id: '1', name: 'iPhone 15 Pro', category: '電子產品', physicalStock: 15, onlineStock: 12, price: 36900, sku: 'APL-IP15P-BLK', isDiscontinued: false },
  { id: '2', name: 'MacBook Air M3', category: '電子產品', physicalStock: 2, onlineStock: 0, price: 35900, sku: 'APL-MBA3-GRY', isDiscontinued: false },
  { id: '3', name: 'Sony WH-1000XM5 降噪耳機', category: '音響設備', physicalStock: 5, onlineStock: 5, price: 9900, sku: 'SNY-WH5-BLK', isDiscontinued: true },
  { id: '4', name: '機械式電競鍵盤', category: '電腦週邊', physicalStock: 10, onlineStock: 0, price: 4500, sku: 'KEY-MECH-RGB', isDiscontinued: false },
  { id: '5', name: '人體工學無線滑鼠', category: '電腦週邊', physicalStock: 25, onlineStock: 20, price: 2900, sku: 'LOGI-MXM3-GR', isDiscontinued: false },
  { id: '6', name: '27吋 4K 專業顯示器', category: '顯示器', physicalStock: 0, onlineStock: 0, price: 15900, sku: 'DEL-U27-4K', isDiscontinued: true },
  { id: '7', name: 'USB-C 多功能集線器', category: '電腦週邊', physicalStock: 15, onlineStock: 15, price: 1800, sku: 'ANK-USB-10G', isDiscontinued: false },
  { id: '8', name: '真皮筆電公事包', category: '生活百貨', physicalStock: 8, onlineStock: 3, price: 3800, sku: 'STYL-BAG-BRW', isDiscontinued: false },
];

export const Icons = {
  Search: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
    </svg>
  ),
  Alert: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
    </svg>
  ),
  Sync: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
    </svg>
  ),
  Plus: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
    </svg>
  ),
  Minus: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
    </svg>
  ),
  Magic: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
    </svg>
  ),
  Cloud: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" />
    </svg>
  ),
  Close: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
    </svg>
  ),
  Sort: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4h13M3 8h9m-9 4h6m4 0l4-4m0 0l4 4m-4-4v12" />
    </svg>
  ),
};
